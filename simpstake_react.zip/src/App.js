
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function App() {
  return (
    <div className="App">
      <h1>Welcome to SimpStake</h1>
      <p>Stake your coins and earn APY!</p>
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById('root'));
